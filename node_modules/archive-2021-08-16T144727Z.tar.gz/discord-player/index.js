module.exports = {
    version: require('./package.json').version,
    Player: require('./src/Player')
}
